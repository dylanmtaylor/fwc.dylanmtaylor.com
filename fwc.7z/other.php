<?php 
require 'beginning.htm';
require 'android.htm';
require 'end.htm';
?>
