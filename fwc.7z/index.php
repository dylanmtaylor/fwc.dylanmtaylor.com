<?php
include("md.php");
$detect = new Mobile_Detect();
if ($detect->isMobile()) {
	require 'beginning.htm';
	if ($detect->isAndroid()) {
		require 'android.htm';
	} else { 
	require 'other.htm';
	 } 
	require 'end.htm';
} else {
	require 'full.php';
}
?>
